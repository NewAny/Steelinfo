/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 50528
Source Host           : localhost:3306
Source Database       : steelinfo

Target Server Type    : MYSQL
Target Server Version : 50528
File Encoding         : 65001

Date: 2016-06-04 11:59:59
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for admin
-- ----------------------------
DROP TABLE IF EXISTS `admin`;
CREATE TABLE `admin` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `adminname` varchar(50) DEFAULT NULL,
  `adminpw` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of admin
-- ----------------------------
INSERT INTO `admin` VALUES ('1', 'test', 'test');
INSERT INTO `admin` VALUES ('2', 'admin', 'admin');
INSERT INTO `admin` VALUES ('14', 'ddd', 'ddd');
INSERT INTO `admin` VALUES ('15', 'sdsd', '呵呵呵');
INSERT INTO `admin` VALUES ('23', ' dss', ' ds');
INSERT INTO `admin` VALUES ('24', 'dsdsd', 'sdsd');
INSERT INTO `admin` VALUES ('25', 'sdsd', 'xxc');
INSERT INTO `admin` VALUES ('26', 'xczcx', 'xzczxczxc');
INSERT INTO `admin` VALUES ('30', 'myname', '哈哈哈');
INSERT INTO `admin` VALUES ('31', 'dddddddd', 'dddddddddd');
INSERT INTO `admin` VALUES ('32', ' dfa', 'sdaf');
INSERT INTO `admin` VALUES ('33', 'afda', 'dfafadsfdd');

-- ----------------------------
-- Table structure for catalog
-- ----------------------------
DROP TABLE IF EXISTS `catalog`;
CREATE TABLE `catalog` (
  `id` int(10) NOT NULL AUTO_INCREMENT COMMENT '编号',
  `catalogName` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of catalog
-- ----------------------------
INSERT INTO `catalog` VALUES ('1', '热轧');
INSERT INTO `catalog` VALUES ('2', '冷轧');
INSERT INTO `catalog` VALUES ('3', '中厚板');

-- ----------------------------
-- Table structure for comment
-- ----------------------------
DROP TABLE IF EXISTS `comment`;
CREATE TABLE `comment` (
  `id` int(11) NOT NULL,
  `title` varchar(50) DEFAULT NULL,
  `content` varchar(250) DEFAULT NULL,
  `time` varchar(50) NOT NULL,
  `productid` int(10) NOT NULL,
  `userid` int(10) NOT NULL,
  PRIMARY KEY (`id`,`productid`),
  KEY `userid` (`userid`),
  KEY `productid` (`productid`),
  CONSTRAINT `comment_ibfk_2` FOREIGN KEY (`userid`) REFERENCES `user` (`id`),
  CONSTRAINT `comment_ibfk_3` FOREIGN KEY (`productid`) REFERENCES `steelproduct` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of comment
-- ----------------------------

-- ----------------------------
-- Table structure for news
-- ----------------------------
DROP TABLE IF EXISTS `news`;
CREATE TABLE `news` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `title` varchar(50) DEFAULT NULL,
  `content` varchar(255) DEFAULT NULL,
  `image` varchar(50) DEFAULT NULL,
  `tital` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of news
-- ----------------------------

-- ----------------------------
-- Table structure for steelproduct
-- ----------------------------
DROP TABLE IF EXISTS `steelproduct`;
CREATE TABLE `steelproduct` (
  `id` int(10) NOT NULL,
  `title` varchar(50) DEFAULT NULL,
  `gonghuoqiu` varchar(50) NOT NULL,
  `guige` varchar(50) DEFAULT NULL,
  `shuliang` varchar(50) DEFAULT NULL,
  `description` varchar(100) DEFAULT NULL,
  `image` varchar(50) DEFAULT NULL,
  `releasetime` datetime DEFAULT NULL COMMENT '发布时间',
  `effectivetime` varchar(50) DEFAULT NULL,
  `catalogId` int(11) DEFAULT NULL,
  `userId` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `steelproduct_ibfk_1` (`userId`),
  KEY `steelproduct_ibfk_2` (`catalogId`),
  CONSTRAINT `steelproduct_ibfk_1` FOREIGN KEY (`userId`) REFERENCES `user` (`id`),
  CONSTRAINT `steelproduct_ibfk_2` FOREIGN KEY (`catalogId`) REFERENCES `catalog` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of steelproduct
-- ----------------------------
INSERT INTO `steelproduct` VALUES ('1', '优质钢材', '供应', '13*13', '20', '很好很好很好很好很好很好很好很好很好很好', '', '2016-05-30 08:16:32', '', '1', '1');
INSERT INTO `steelproduct` VALUES ('2', '优质钢材', '供应', '13*13', '20', '很好很好很好很好很好很好很好很好很好很好', '', '2016-05-30 08:16:32', '', '1', '1');
INSERT INTO `steelproduct` VALUES ('3', '优质钢材', '供应', '13*13', '20', '很好很好很好很好很好很好很好很好很好很好', '', '2016-05-30 08:16:32', '', '1', '1');
INSERT INTO `steelproduct` VALUES ('5', '优质钢材', '供应', '13*13', '20', '很好很好很好很好很好很好很好很好很好很好', '', '2016-05-30 08:16:32', '', '1', '1');
INSERT INTO `steelproduct` VALUES ('6', '优质钢材', '供应', '13*13', '20', '很好很好很好很好很好很好很好很好很好很好', '', '2016-05-30 08:16:32', '', '1', '1');

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) DEFAULT NULL,
  `userpw` varchar(50) DEFAULT NULL,
  `realname` varchar(50) DEFAULT NULL,
  `age` int(10) DEFAULT NULL,
  `sex` varchar(10) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `qq` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL COMMENT '审核状态',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES ('1', 'test', 'test', '张三', '20', '男', '1876666666', '123456789', '12@qq.com', '');
INSERT INTO `user` VALUES ('3', 'ss', 'tesd', '张三', '20', '男', '1876666666', '123456789', '12@qq.com', '');
INSERT INTO `user` VALUES ('4', 'tesd', 'test', '张三', '20', '男', '1876666666', '123456789', '12@qq.com', '');
INSERT INTO `user` VALUES ('11', 'd', 'd', null, null, null, '6678900', null, '223@dd.com', null);
INSERT INTO `user` VALUES ('12', 'dd', 'd', null, null, null, '22', null, 'dsf@dd', null);
