function login(){
	
	$("#form").submit();
/*	window.location.href="/user/userlogin";*/
}

function update(){
	
	$("#for").submit();
}

function insert(){
	window.location.href="/admin/insert";
}

function add(){
	
	$("#add").submit();
}
function addcata(){
	
	$("#addcata").submit();
}

function insertCatalog(){
	window.location.href="/catalog/insertcatalog";
}

function insertUser(){
	window.location.href="/user/insert";
}

function addUser(){
	window.location.href="/user/insert";
}