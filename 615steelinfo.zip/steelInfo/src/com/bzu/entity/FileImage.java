package com.bzu.entity;

import java.io.File;

public class FileImage {
	private File file;
	private String contentType;
	private String filename;


	@Override
	public String toString() {
		return "FileImage [file=" + file + ", contentType=" + contentType + ", filename=" + filename + "]";
	}
	public File getFile() {
		return file;
	}
	public String getContentType() {
		return contentType;
	}
	public String getFilename() {
		return filename;
	}
	/**
	 * �������ڵı���ContentType() FileName()
	 * ǰ��ע�벻�Ǹ������Զ��Ǹ���set����
	 * @param file
	 */
	public void setUpload(File file) {
		this.file=file;
		
	}
	public void setUploadContentType(String contentType) {
		this.contentType=contentType;
		
	}
	public void setUploadFileName(String filename){
		this.filename=filename;
	}


}
