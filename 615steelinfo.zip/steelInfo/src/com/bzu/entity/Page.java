package com.bzu.entity;

import java.util.List;


@SuppressWarnings("rawtypes")
public class Page {
	private List data;
	private int totalRow;// �ܼ�¼��
	private int totalPage;// ��ҳ��
	private int currentPage=1;// ��ǰҳ
	private int pageSize=5;// ÿҳ��¼��
	int param = 0;
	
	
	public Page() {
		super();
	}

	public Page( int totalRow, int totalPage, int currentPage,
			int pageSize, int param) {
		super();
		this.totalRow = totalRow;
		this.totalPage = totalPage;
		this.currentPage = currentPage;
		this.pageSize = pageSize;
		this.param = param;
	}

	public int getTotalRow() {
		return totalRow;
	}

	public void setTotalRow(int totalRow) {
		this.totalRow = totalRow;
	}

	public int getTotalPage() {
		return totalPage;
	}

	public void setTotalPage(int totalPage) {
		this.totalPage = totalPage;
	}

	public int getCurrentPage() {
		return currentPage;
	}

	public void setCurrentPage(int currentPage) {
		this.currentPage = currentPage;
	}

	public int getPageSize() {
		return pageSize;
	}

	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}

	public int getParam() {
		return param;
	}

	public void setParam(int param) {
		this.param = param;
	}

	public List getData() {
		return data;
	}

	public void setData(List data) {
		this.data = data;
	}

	
}
