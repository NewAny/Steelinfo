package com.bzu.entity;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="steelproduct")
public class Steelproduct {
	private Integer id;

	private Integer catalogId;

	private Integer userId;
	private String title;
	private Integer  gonghuoqiu;//�� ��
	private String guige; //���
	private String shuliang;//����
	private String description;
	private String image;
	private Date  releasetime;//����ʱ��  
	private String effectivetime;
	
	@Id
	@GeneratedValue
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getCatalogId() {
		return catalogId;
	}
	public void setCatalogId(Integer catalogId) {
		this.catalogId = catalogId;
	}
	public Integer getUserId() {
		return userId;
	}
	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}

	public Integer getGonghuoqiu() {
		return gonghuoqiu;
	}
	public void setGonghuoqiu(Integer gonghuoqiu) {
		this.gonghuoqiu = gonghuoqiu;
	}
	public String getGuige() {
		return guige;
	}
	public void setGuige(String guige) {
		this.guige = guige;
	}
	public String getShuliang() {
		return shuliang;
	}
	public void setShuliang(String shuliang) {
		this.shuliang = shuliang;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	public Date getReleasetime() {
		return releasetime;
	}
	public void setReleasetime(Date releasetime) {
		this.releasetime = releasetime;
	}
	public String getEffectivetime() {
		return effectivetime;
	}
	public void setEffectivetime(String effectivetime) {
		this.effectivetime = effectivetime;
	}
	@Override
	public String toString() {
		return "Steelproduct [id=" + id + ", catalogId=" + catalogId + ", userId=" + userId + ", title=" + title
				+ ", gonghuoqiu=" + gonghuoqiu + ", guige=" + guige + ", shuliang=" + shuliang + ", description="
				+ description + ", image=" + image + ", releasetime=" + releasetime + ", effectivetime=" + effectivetime
				+ "]";
	}
	
	

}
