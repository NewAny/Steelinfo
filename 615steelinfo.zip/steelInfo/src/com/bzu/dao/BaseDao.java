package com.bzu.dao;

import java.util.List;
import java.util.Map;
/**
 * ҵ���Ҳ�޴ӳ��õķ�����ȡ���˴�
 * <li>void save(T t)��</li>
 * <li>void delete(int id)ɾbyid</li>
 * <li>void delete(T t)ɾ</li>
 * <li>void update(T t)��</li>
 * <li> T get(int id)��</li>
 * <li>List<T> query()ȡ�ü���</li>
 * <li>int total()�ܼ�¼��</li>
 * 
 * @author ASUS
 *
 * @param <T>
 */
public interface BaseDao<T> {
	
	public void save(T t);
	public void delete(int id);
	public void delete(T t);
	public void update(T t);
	public  T get(int id);
	public List<Map<String, Object>> queryAllList();
	public List<Map<String, Object>> queryPageList(Map<String, Object> map);
	
	public int total(Map<String, Object> map);
	

}
