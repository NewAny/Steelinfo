package com.bzu.dao;

import com.bzu.entity.Catalog;

public interface CatalogDao extends BaseDao<Catalog> {

}
