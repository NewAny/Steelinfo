package com.bzu.dao;

import com.bzu.entity.Admin;

public interface AdminDao extends BaseDao<Admin> {

	public Admin login(String adminname, String adminpw);
}
