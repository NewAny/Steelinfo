package com.bzu.dao;

import java.util.List;
import java.util.Map;

import com.bzu.entity.Comment;

public interface CommentDao extends BaseDao<Comment> {

	List<Map<String, Object>> queryAllListByUserId(int id);

}
