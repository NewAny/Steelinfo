package com.bzu.dao.impl;

import org.springframework.stereotype.Repository;

import com.bzu.dao.NewsDao;
import com.bzu.entity.News;
@Repository
public class NewsDaoImpl extends BaseDaoImpl<News> implements NewsDao {


}
