package com.bzu.dao.impl;


import java.util.List;
import java.util.Map;

import org.hibernate.Query;
import org.springframework.stereotype.Repository;

import com.bzu.dao.SteelproductDao;
import com.bzu.entity.Steelproduct;
@Repository
public class SteelproductDaoImpl extends BaseDaoImpl<Steelproduct> implements SteelproductDao {

	@SuppressWarnings("unchecked")
	@Override
	public List<Map<String, Object>> queryAllListByUserId(int id) {
		// TODO Auto-generated method stub
		String hql="FROM  Steelproduct as s where s.userId="+id+" order by releasetime desc";
		
		List<Map<String, Object>> list= getSession().createQuery(hql).list();
		return list;
	}
	/**
	 * ������ѯ
	 */

	@SuppressWarnings("unchecked")
	@Override
	public List<Map<String, Object>> querySteelLeftJoinAllList(Map<String, Object> map) {
/*String sql="SELECT DISTINCT * FROM `steelproduct` st "
		+ " LEFT JOIN USER u ON st.`userId` = u.`id` "
		+ " LEFT JOIN catalog ca ON st.`catalogId` = ca.`id` "
		+ " ORDER BY releasetime DESC";
 	private Integer id;
	private Integer catalogId;
	private Integer userId;
	private String title;
	private Integer  gonghuoqiu;//�� ��
	private String guige; //���
	private String shuliang;//����
	private String description;
	private String image;
	private Date  releasetime;//����ʱ��  
	private String effectivetime;
	
	private Integer id;
	private String catalogName;
	
	private Integer id;
	private String username;
	private String userpw;
	private String realname;
	private Integer age;
	private String sex;
	private String qq;
	private String phone;	
	private String email;
	private String status;
	
	*/	
	//	String sql="SELECT DISTINCT st.id,st.catalogId,st.title,st.gonghuoqiu,st.guige,st.shuliang,st.description,st.image,	st.releasetime,st.effectivetime,ca.catalogName,u.username,u.realname,u.age,u.sex,u.qq,u.phone,u.email,u.status  FROM `steelproduct` st  LEFT JOIN USER u ON st.`userId` = u.`id` LEFT JOIN catalog ca ON st.`catalogId` = ca.`id`	ORDER BY releasetime DESC";
	//	@SuppressWarnings("unchecked")
	//	List<Map<String, Object>> list= getSession().createSQLQuery(sql).list();//getSession().createQuery(hql).list();
	//	return list;
		String sql="SELECT DISTINCT st.id,st.catalogId,st.title,st.gonghuoqiu,st.guige,st.shuliang,st.description,st.image,	st.releasetime,st.effectivetime,ca.catalogName,u.username,u.realname,u.age,u.sex,u.qq,u.phone,u.email,u.status  FROM `steelproduct` st  LEFT JOIN USER u ON st.`userId` = u.`id` LEFT JOIN catalog ca ON st.`catalogId` = ca.`id`   ";
		System.out.println(sql);
		if(map.get("gonghuoqiu") != null && (Integer)map.get("gonghuoqiu")==1 ){
			sql += " where st.gonghuoqiu = 1 ";//��Ӧ
		}  
		if(map.get("gonghuoqiu") != null && (Integer)map.get("gonghuoqiu")==2 ){
			sql += " where st.gonghuoqiu = 2 ";//��
		}
		sql += "  ORDER BY releasetime DESC";
		  getSession().createSQLQuery(sql);
		Query query = getSession().createSQLQuery(sql);
	      query.setFirstResult((int) map.get("pageOffset"));
	      query.setMaxResults((int) map.get("pageSize"));
	     return  query.list();
	}
	
}
