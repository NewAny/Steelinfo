package com.bzu.dao.impl;

import org.hibernate.Query;
import org.springframework.stereotype.Repository;

import com.bzu.dao.AdminDao;
import com.bzu.entity.Admin;
//   �������� �������е�
@Repository
public class AdminDaoImpl extends BaseDaoImpl<Admin> implements AdminDao {

	

	@Override
	public Admin login(String adminname, String adminpw) {
		// TODO Auto-generated method stub
		Admin admin=null;
		Query query = getSession().createQuery("from Admin where adminname=? and adminpw=?");
		query.setString(0, adminname);
		query.setString(1, adminpw);
		admin=(Admin) query.uniqueResult();
		return admin;
	}

}
