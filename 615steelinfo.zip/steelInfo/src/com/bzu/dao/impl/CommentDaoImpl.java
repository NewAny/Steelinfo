package com.bzu.dao.impl;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.bzu.dao.CommentDao;
import com.bzu.entity.Comment;
@Repository
public class CommentDaoImpl extends BaseDaoImpl<Comment> implements CommentDao {

	@Override
	public List<Map<String, Object>> queryAllListByUserId(int id) {
		// TODO Auto-generated method stub
String hql="FROM  Comment as c where c.receiveid="+id+" order time desc";
		
		List<Map<String, Object>> list= getSession().createQuery(hql).list();
		return list;
	}

	
}
