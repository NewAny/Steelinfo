package com.bzu.dao.impl;

import java.lang.reflect.ParameterizedType;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Repository;

import com.bzu.dao.BaseDao;

/**
 * ���ݲ㳣�õķ�����ȡ���˴�
 * <li>void save(T t)��</li>
 * <li>void delete(int id)ɾbyid</li>
 * <li>void delete(T t)ɾ</li>
 * <li>void update(T t)��</li>
 * <li> T get(int id)��</li>
 * <li>List<T> query()ȡ�ü���</li>
 * <li>int total()�ܼ�¼��</li>
 * <li>queryPageList(Map<String, Object> map)��ҳ��ѯ</li>
 * 
 * @author ASUS
 *
 * @param <T>
 */
@SuppressWarnings("unchecked")
@Repository
@Lazy(true)
public class BaseDaoImpl<T> implements BaseDao<T> {
 
	
	@SuppressWarnings("rawtypes")
	private Class clazz;//��ǰ����������
	
	@Resource
	private SessionFactory sessionFactory;
	
	
	
	@SuppressWarnings("rawtypes")
	public BaseDaoImpl() {
		System.out.println("BaseDaoImpl(this�����ĵ�ǰ���õĹ��췽������"+this);
	    System.out.println("��ȡ��ǰ����ĸ�����Ϣ"+this.getClass().getSuperclass());
	    System.out.println("��ȡ��ǰ����ĸ�����Ϣ(��������)"+this.getClass().getGenericSuperclass());
	   
	    ParameterizedType type= (ParameterizedType) this.getClass().getGenericSuperclass();
	    
	    clazz=(Class)type.getActualTypeArguments()[0];
	    System.out.println("��ȡ������Ϣ"+clazz);
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	public Session getSession() {
		return sessionFactory.getCurrentSession();
	}

	@Override
	public void save(T t) {
		// TODO Auto-generated method stub
		getSession().save(t);
		
	}

	@Override
	public void delete(int id) {
		// TODO Auto-generated method stub
		String hql="DELETE "+clazz.getSimpleName()+" WHERE id=:id";
		System.out.println(hql+id);
		getSession().createQuery(hql).setInteger("id", id).executeUpdate();
	}

	@Override
	public void delete(T t) {
		// TODO Auto-generated method stub
		getSession().delete(t);
		
	}

	@Override
	public void update(T t) {
		// TODO Auto-generated method stub
		getSession().update(t);
		
	}

	
	@Override
	public T get(int id) {
		// TODO Auto-generated method stub
		return (T)getSession().get(clazz, id);
	}

	

	@Override
	public int total(Map<String, Object> map) {
		String hql = "select count(*) from "+clazz.getSimpleName();
		if((Integer)map.get("gonghuoqiu") == 1){
			hql += " where gonghuoqiu = 1";
		}
		if((Integer)map.get("gonghuoqiu") == 2){
			hql += " where gonghuoqiu = 2";
		}
		SQLQuery query = getSession().createSQLQuery(hql);
		Integer num = Integer.parseInt(String.valueOf(query.uniqueResult()));
		return num;
	}
	/**
	 * ��ѯ����
	 */
	@Override
	public List<Map<String, Object>> queryAllList() {
		// TODO Auto-generated method stub
		String hql="FROM "+clazz.getSimpleName();//���е�
		if(clazz.getSimpleName().equals("Steelproduct"))//�����Steelproduct������ʱ�䵹��
			hql += " order by releasetime desc";
		if(clazz.getSimpleName().equals("News"))//�����News������ʱ�䵹��
			hql += " order by time desc";
		return getSession().createQuery(hql).list();
	}
/**
 * ��ҳ��ѯ
 */
	@Override
	public List<Map<String, Object>> queryPageList(Map<String, Object> map) {
		// TODO Auto-generated method stub
//		String hql="FROM "+clazz.getSimpleName()+" LIMIT "+map.get("pageOffset")+","+map.get("pageSize");
//		return getSession().createQuery(hql).list();
		
		
		String hql="FROM "+clazz.getSimpleName();
		System.out.println(hql);
		if(map.get("gonghuoqiu") != null && (Integer)map.get("gonghuoqiu")==1 ){
			hql += " where gonghuoqiu = 1";//��Ӧ
		}  
		if(map.get("gonghuoqiu") != null && (Integer)map.get("gonghuoqiu")==2 ){
			hql += " where gonghuoqiu = 2";//��
		}
		if(clazz.getSimpleName().equals("Steelproduct")){//�����Steelproduct������ʱ�䵹��
		hql += " order by releasetime desc";
		}
		if(clazz.getSimpleName().equals("News"))//�����News������ʱ�䵹��
			hql += " order by time desc";
		if(clazz.getSimpleName().equals("Comment"))//�����News������ʱ�䵹��
			hql += " order by time desc";
		
	      Query query = getSession().createQuery(hql);
	      query.setFirstResult((int) map.get("pageOffset"));
	      query.setMaxResults((int) map.get("pageSize"));
	     return  query.list();
		
	}

	/*public List<ParamGroup> doInHibernate(Session session) throws HibernateException,
			SQLException {
		List<ParamGroup> list  = null;
		Query query = session.createQuery("from ParamGroup");
		query.setFirstResult((pb.getCurrentPageNum()-1)*pb.getPageSize());
		query.setMaxResults(pb.getPageSize());
		list = query.list();
		return list;
	}*/
	

}
