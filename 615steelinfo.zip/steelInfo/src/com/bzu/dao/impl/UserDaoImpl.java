package com.bzu.dao.impl;

import org.hibernate.Query;
import org.springframework.stereotype.Repository;

import com.bzu.dao.UserDao;
import com.bzu.entity.User;
@Repository
public class UserDaoImpl extends BaseDaoImpl<User> implements UserDao{
	@Override
	public User login(String username, String userpw) {
		// TODO Auto-generated method stub
		User user=null;
		Query query = getSession().createQuery("from User where username=? and userpw=?");
		query.setString(0, username);
		query.setString(1, userpw);
		user=(User) query.uniqueResult();
		return user;
	}
}
