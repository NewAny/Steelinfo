package com.bzu.dao.impl;

import org.springframework.stereotype.Repository;

import com.bzu.dao.CatalogDao;
import com.bzu.entity.Catalog;
@Repository
public class CatalogDaoImpl extends BaseDaoImpl<Catalog> implements CatalogDao {

}
