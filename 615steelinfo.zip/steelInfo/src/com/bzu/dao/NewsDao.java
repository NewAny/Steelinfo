package com.bzu.dao;

import com.bzu.entity.News;

public interface NewsDao extends BaseDao<News> {

}
