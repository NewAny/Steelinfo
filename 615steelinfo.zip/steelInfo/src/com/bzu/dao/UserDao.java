package com.bzu.dao;

import com.bzu.entity.User;

public interface UserDao extends BaseDao<User> {

public 	User login(String username, String userpw);

}
