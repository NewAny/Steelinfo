package com.bzu.tools;

import java.io.File;
import java.util.UUID;

import org.apache.commons.io.FilenameUtils;
import org.aspectj.util.FileUtil;
import org.springframework.stereotype.Component;

import com.bzu.entity.FileImage;
@Component("fileUpload")
public class FileUploadUtil implements FileUpload {
	private String filePath;
public String getFilePath() {
		return filePath;
	}
	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}
	//1ͨ���ļ����ȡ��չ��
	private String getFileExt(String fileName) {
		return FilenameUtils.getExtension(fileName);
				
	}
	//2����UUID���������Ϊ�µ��ļ���
	private String newFileName(String fileName) {
		String ext=getFileExt(fileName);
		return UUID.randomUUID().toString()+"."+ext;
	}
	//3:ʵ���ļ��ϴ����� �����µ��ļ�����
	/* (non-Javadoc)
	 * @see com.bzu.tools.FileUpload#uploadFile(com.bzu.entity.FileImage)
	 */
	@Override
	public String uploadFile(FileImage fileImage) {
		
	String pic=	newFileName(fileImage.getFilename());
	
	try{
		FileUtil.copyFile(fileImage.getFile(), new File(filePath,pic));
		return pic;
	}catch(Exception e){
		throw new RuntimeException(e);
	}finally {
		fileImage.getFile().delete();
	}
	
	}
}
