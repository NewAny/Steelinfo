package com.bzu.tools;

import com.bzu.dao.BaseDao;
import com.bzu.dao.impl.AdminDaoImpl;
import com.bzu.dao.impl.BaseDaoImpl;
import com.bzu.entity.Admin;
import com.bzu.service.impl.AdminServiceImpl;
import com.bzu.service.impl.BaseServiceImpl;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		new AdminServiceImpl();
		new BaseServiceImpl<>();
	}

}
