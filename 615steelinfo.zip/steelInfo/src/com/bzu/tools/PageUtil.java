package com.bzu.tools;


import java.util.List;

import com.bzu.entity.Page;


public class PageUtil {
	/**
	 * ������ҳ��,��̬����,���ⲿֱ��ͨ����������
	 * @param pageSize ÿҳ��¼��
	 * @param allRow �ܼ�¼��
	 * @return ��ҳ��
	 */
	public static int countTotalPage(final int pageSize, final int totalRow) {
		int totalPage = totalRow % pageSize == 0 ? totalRow / pageSize : totalRow
				/ pageSize + 1;
		return totalPage;
	}

	/**
	 * ���㵱ǰҳ��ʼ��¼
	 * @param pageSize ÿҳ��¼��
	 * @param currentPage ��ǰ�ڼ�ҳ
	 * @return ��ǰҳ��ʼ��¼��
	 */
	public static int getPageOffset(final int pageSize, final int currentPage) {
		final int offset = pageSize * (currentPage - 1);
		return offset;
	}
	
	/**
	 * 
	 * @param currentPage
	 * @param pageSize
	 * @param totalRow
	 * @param list
	 * @return
	 */
	public static Page getPage(int currentPage, int pageSize, int totalRow, List<?> list){
		Page page = new Page();
		page.setCurrentPage(currentPage);
		page.setPageSize(pageSize);
		page.setTotalRow(totalRow);
		page.setTotalPage(countTotalPage(pageSize, totalRow));
		page.setData(list);
		return page;
	}
	
	public static int getLastPageRow(int pageSize, int totalRow, int totalPage){
		return totalRow - pageSize * (totalPage - 1);
	}
	
}
