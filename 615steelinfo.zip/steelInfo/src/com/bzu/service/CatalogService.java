package com.bzu.service;

import com.bzu.entity.Catalog;

public interface CatalogService extends BaseService<Catalog> {

}
