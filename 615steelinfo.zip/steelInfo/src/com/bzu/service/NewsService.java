package com.bzu.service;

import com.bzu.entity.News;

public interface NewsService extends BaseService<News> {

}
