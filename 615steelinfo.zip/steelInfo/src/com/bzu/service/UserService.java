package com.bzu.service;

import com.bzu.entity.User;

public interface UserService extends BaseService<User> {
	User login(String username, String userpw);

}
