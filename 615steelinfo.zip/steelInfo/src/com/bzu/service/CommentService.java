package com.bzu.service;

import java.util.List;
import java.util.Map;

import com.bzu.entity.Comment;

public interface CommentService extends BaseService<Comment> {
	public   List<Map<String, Object>> queryListByuserid(int id);

}
