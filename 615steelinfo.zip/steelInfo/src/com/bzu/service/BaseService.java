package com.bzu.service;

import java.util.List;
import java.util.Map;

import com.bzu.entity.Page;
import com.bzu.entity.User;
/**
 * ���ݲ㳣�õķ�����ȡ���˴�
 * <li>void save(T t)��</li>
 * <li>void delete(int id)ɾbyid</li>
 * <li>void delete(T t)ɾ</li>
 * <li>void update(T t)��</li>
 * <li> T get(int id)��</li>
 * <li>List<T> query()ȡ�ü���</li>
 * <li>int total()�ܼ�¼��</li>
 * <li>pageList(Page p) Page</li>
 * 
 * @author ASUS
 *
 * @param <T>
 */
public interface BaseService<T> {
	
	public void add(T t);
	public void delete(int id);
	public void delete(T t);
	public void update(T t);
	public  T get(int id);
	public List<Map<String, Object>> queryAllList();
	public int total();
	public void init();
	public Page pageList(Page p);

	
	

}
