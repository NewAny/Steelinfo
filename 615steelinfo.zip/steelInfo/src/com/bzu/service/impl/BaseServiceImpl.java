package com.bzu.service.impl;

import java.lang.reflect.Field;
import java.lang.reflect.ParameterizedType;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;



import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

import com.bzu.dao.AdminDao;
import com.bzu.dao.BaseDao;
import com.bzu.dao.CatalogDao;
import com.bzu.dao.CommentDao;
import com.bzu.dao.NewsDao;
import com.bzu.dao.SteelproductDao;
import com.bzu.dao.UserDao;
import com.bzu.entity.Page;

import com.bzu.service.BaseService;
import com.bzu.tools.PageUtil;

/**
 * �����õķ�����ȡ���˴�
 * <li>void save(T t)��</li>
 * <li>void delete(int id)ɾbyid</li>
 * <li>void delete(T t)ɾ</li>
 * <li>void update(T t)��</li>
 * <li> T get(int id)��</li>
 * <li>List<T> query()ȡ�ü���</li>
 * <li>int total()�ܼ�¼��</li>
 * @author ASUS
 * @param <T>
 */
@Service
@Lazy(true)
public class BaseServiceImpl<T> implements BaseService<T> {
	private Class clazz;
		public BaseServiceImpl() {
		System.out.println("BaseServiceImpl()this�����ĵ�ǰ���õĹ��췽������"+this);
	    System.out.println("��ȡ��ǰ����ĸ�����Ϣ"+this.getClass().getSuperclass());
	    System.out.println("��ȡ��ǰ����ĸ�����Ϣ(��������)"+this.getClass().getGenericSuperclass());
	   	ParameterizedType type= (ParameterizedType) this.getClass().getGenericSuperclass();
	    clazz=(Class)type.getActualTypeArguments()[0];
	    System.out.println("��ȡ������Ϣ"+clazz);
	    System.out.println("==================baseDao"+baseDao);
	}
	@PostConstruct	
	public void init(){
		
		System.out.println("I'm  init  method  using  @PostConstrut...."); 
		//Dao���� ����clazz�����ͣ��Ѳ�ͬ��dao����ֵ��baseDao����
		System.out.println("===Dao���� ����clazz�����ͣ��Ѳ�ͬ��dao����̬��ֵ��baseDao����===============baseDao");
		String clazzName=clazz.getSimpleName();
		String clazzDao=clazzName.substring(0, 1).toLowerCase()+clazzName.substring(1)+"Dao";
		try {
		   Field clazzField= this.getClass().getSuperclass().getDeclaredField(clazzDao) ;
		   Field  baseField= this.getClass().getSuperclass().getDeclaredField("baseDao");
		   baseField.set(this, clazzField.get(this));
		   
		} catch (Exception e) {
			// TODO Auto-generated catch block
			throw new RuntimeException(e);
		}
		System.out.println("==================baseDao"+baseDao);
	
	}
	

	protected BaseDao<T>  baseDao;
	
	public void setBaseDao(BaseDao<T> baseDao) {
		this.baseDao = baseDao;
	}


	public void setAdminDao(AdminDao adminDao) {
		this.adminDao = adminDao;
	}


	public void setCatalogDao(CatalogDao catalogDao) {
		this.catalogDao = catalogDao;
	}


	public void setCommentDao(CommentDao commentDao) {
		this.commentDao = commentDao;
	}


	public void setNewsDao(NewsDao newsDao) {
		this.newsDao = newsDao;
	}


	public void setSteelproductDao(SteelproductDao steelproductDao) {
		this.steelproductDao = steelproductDao;
	}


	public void setUserDao(UserDao userDao) {
		this.userDao = userDao;
	}


	@Resource
	protected AdminDao adminDao;
	
	@Resource
	protected CatalogDao catalogDao;
	
	@Resource
	protected CommentDao commentDao;
	
	@Resource
	protected NewsDao newsDao;
	
	@Resource
	protected SteelproductDao steelproductDao;
	
	@Resource
	protected UserDao userDao;


	
	@Override
	public void add(T t) {
		// TODO Auto-generated method stub
		System.out.println("------"+clazz.getSimpleName()+"Impl.add--------"+toString());
		baseDao.save(t);
		
	}

	@Override
	public void delete(int id) {
		// TODO Auto-generated method stub
		System.out.println("------"+clazz.getSimpleName()+"Impl.delete---------byid="+id);	
		baseDao.delete(id);
		
	}

	@Override
	public void delete(T t) {
		// TODO Auto-generated method stub
		System.out.println("------"+clazz.getSimpleName()+"Impl.delete--------"+t.toString());
		baseDao.delete(t);
		
	}

	@Override
	public void update(T t) {
		// TODO Auto-generated method stub
		System.out.println("------"+clazz.getSimpleName()+"Impl.add--------"+t.toString());
		baseDao.update(t);
		
	}

	@Override
	public T get(int id) {
		// TODO Auto-generated method stub
		System.out.println("------"+clazz.getSimpleName()+"Impl.get--------byid="+id);
		   System.out.println(baseDao.getClass().toString());
		return   baseDao.get(id);
	}

	@Override
	public List<Map<String, Object>> queryAllList() {
		// TODO Auto-generated method stub
		System.out.println("------"+clazz.getSimpleName()+"Impl.queryAlllist--------");
		return baseDao.queryAllList();
	}

	@Override
	public int total() {
		// TODO Auto-generated method stub
		System.out.println("------"+clazz.getSimpleName()+"Impl.total--------");
		Map<String,Object> map = new HashMap<String,Object>();
		return baseDao.total(map);
	}
	//��װpage
	@Override
	public Page pageList(Page p) 
	{
		// TODO Auto-generated method stub
		Map<String,Object> map = new HashMap<String,Object>();
		map.put("gonghuoqiu", p.getParam());//1��Ӧ 2��
		//ǰ̨�������ķ�ҳ��Ϣ
		int currentPage =1;
		if(p!=null){
			currentPage = p.getCurrentPage();
		}
		int pageSize =5;
		int totalRow = baseDao.total(map);
		int pageOffset = PageUtil.getPageOffset(pageSize, currentPage);
		map.put("pageOffset", pageOffset);
		map.put("pageSize", pageSize);
		//��ѯ�б�????
		List<Map<String, Object>> baseList = baseDao.queryPageList(map);
		
		p = PageUtil.getPage(currentPage, pageSize, totalRow, baseList);
		System.out.println(p.toString());
		return p;
	}


}
