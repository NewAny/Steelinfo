package com.bzu.service.impl;

import org.springframework.stereotype.Service;

import com.bzu.entity.News;
import com.bzu.service.NewsService;
@Service
public class NewsServiceImpl extends BaseServiceImpl<News> implements NewsService {

}
