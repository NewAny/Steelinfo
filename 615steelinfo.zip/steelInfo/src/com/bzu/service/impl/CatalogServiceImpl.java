package com.bzu.service.impl;

import org.springframework.stereotype.Service;

import com.bzu.entity.Catalog;
import com.bzu.service.CatalogService;

@Service
public class CatalogServiceImpl extends BaseServiceImpl<Catalog> implements CatalogService {

}
