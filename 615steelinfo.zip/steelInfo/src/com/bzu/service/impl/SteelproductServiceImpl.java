package com.bzu.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.Id;

import org.springframework.stereotype.Service;

import com.bzu.dao.SteelproductDao;
import com.bzu.entity.Page;
import com.bzu.entity.Steelproduct;
import com.bzu.service.SteelproductService;
import com.bzu.tools.PageUtil;
@Service
public class SteelproductServiceImpl extends BaseServiceImpl<Steelproduct> implements SteelproductService {

	@Override
	public List<Map<String, Object>> queryAllListByUserId(int id) {
		// TODO Auto-generated method stub
		return  steelproductDao.queryAllListByUserId(id);
	}
	public Page leftJoinPageList(Page p) 
	{
		// TODO Auto-generated method stub
		Map<String,Object> map = new HashMap<String,Object>();
		map.put("gonghuoqiu", p.getParam());//1��Ӧ 2��
		//ǰ̨�������ķ�ҳ��Ϣ
		int currentPage =1;
		if(p!=null){
			currentPage = p.getCurrentPage();
		}
		int pageSize =5;//ÿҳ��ʾ5��
		int totalRow = steelproductDao.total(map);
		int pageOffset = PageUtil.getPageOffset(pageSize, currentPage);
		map.put("pageOffset", pageOffset);
		map.put("pageSize", pageSize);
		//��ѯ�б�????
		List<Map<String, Object>> steelproductList = steelproductDao.querySteelLeftJoinAllList(map);
		
		p = PageUtil.getPage(currentPage, pageSize, totalRow, steelproductList);
		System.out.println(p.toString());
		return p;
	}

}
