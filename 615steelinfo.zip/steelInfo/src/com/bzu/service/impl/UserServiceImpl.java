package com.bzu.service.impl;

import org.springframework.stereotype.Service;

import com.bzu.entity.User;
import com.bzu.service.UserService;
@Service
public class UserServiceImpl extends BaseServiceImpl<User> implements UserService {

	@Override
	public User login(String username, String userpw) {
		// TODO Auto-generated method stub
		return userDao.login(username,userpw);
	}
}
