package com.bzu.service.impl;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.bzu.entity.Comment;
import com.bzu.service.CommentService;
@Service
public class CommentServiceImpl extends BaseServiceImpl<Comment> implements CommentService {

	@Override
	public List<Map<String, Object>> queryListByuserid(int id) {
		return  commentDao.queryAllListByUserId(id);
	}

}
