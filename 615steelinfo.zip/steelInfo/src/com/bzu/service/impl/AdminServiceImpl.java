package com.bzu.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.stereotype.Service;
import com.bzu.entity.Admin;
import com.bzu.entity.Page;
import com.bzu.service.AdminService;
import com.bzu.tools.PageUtil;
@Service
public class AdminServiceImpl extends BaseServiceImpl<Admin>  implements AdminService {

	
	@Override
	public Admin login(String adminname, String adminpw) {
		// TODO Auto-generated method stub
		return adminDao.login(adminname, adminpw);
	}
	/*@Override
	public Page adminList(Page p) {
		// TODO Auto-generated method stub
		Map<String,Object> map = new HashMap<String,Object>();
		//ǰ̨�������ķ�ҳ��Ϣ
		int currentPage =1;
		if(p!=null){
			currentPage = p.getCurrentPage();
		}
		int pageSize =10;
		int totalRow = adminDao.total();
		int pageOffset = PageUtil.getPageOffset(pageSize, currentPage);
		map.put("pageOffset", pageOffset);
		map.put("pageSize", pageSize);
		//��ѯ�б�
		List<Map<String, Object>> userList = adminDao.queryAllList();
		System.out.println("-------------"+userList.size()+userList.toString()+"--------------------");
		p = PageUtil.getPage(currentPage, pageSize, totalRow, userList);
		System.out.println(p.toString());
		return p;
	}
	*/
}
