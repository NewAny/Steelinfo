package com.bzu.service;

import java.util.List;
import java.util.Map;

import com.bzu.entity.Page;
import com.bzu.entity.Steelproduct;

public interface SteelproductService extends BaseService<Steelproduct> {

	public   List<Map<String, Object>>  queryAllListByUserId(int id);
	
	public Page leftJoinPageList(Page p) ;
}
