package com.bzu.service;

import com.bzu.entity.Admin;
import com.bzu.entity.Page;

public interface AdminService extends BaseService<Admin> {

	public Admin login(String adminname, String adminpw);

}
