package com.bzu.action;

import java.lang.reflect.ParameterizedType;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.struts2.interceptor.ApplicationAware;
import org.apache.struts2.interceptor.RequestAware;
import org.apache.struts2.interceptor.SessionAware;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;

import com.bzu.entity.FileImage;
import com.bzu.entity.Page;
import com.bzu.service.AdminService;
import com.bzu.service.CatalogService;
import com.bzu.service.CommentService;
import com.bzu.service.NewsService;
import com.bzu.service.SteelproductService;
import com.bzu.service.UserService;
import com.bzu.tools.FileUpload;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

/**
 * Strutsִ�����̣��ȴ���action �ڵ��������� �����������ʳɹ� �ڵ���action����
 * 
 * ����Ŀ������ʱ�� Struts�Ĺ��������Ѿ�����Ӧ�����ö��󣬺����ö����Ӧ��Map�洢��actioncontext��֮ս��
 * ���ʵ����Ӧ��*****ware�ӿڣ��ͻ�actioncontext �л�ȡ��Ӧ��map���д��� ʵ�ֵ�������Ϊ��Ĭ��18����
 * @author ASUS
 *
 * @param <T>
 */
@Controller("baseAction")//��д���־�����������һ����ĸСд����ͬ����һ��
@Scope("prototype")
public class BaseAction<T> extends ActionSupport implements RequestAware,SessionAware,ApplicationAware,ModelDriven<T> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;


	protected T model;   //model�п���Ϊadmin user steelproduct Catalog �ȵ�
	
	protected List data;// Ҫ���ص�ĳһҳ�ļ�¼�б�
	protected int totalRow;// �ܼ�¼��
	protected int totalPage;// ��ҳ��
	protected int currentPage=1;// ��ǰҳ
	protected int pageSize=10;// ÿҳ��¼��
	protected int param = 0;

	protected FileImage	 fileImage;
	
	
	protected Map<String,Object> appliction; 
	protected Map<String,Object> session; 
	protected Map<String,Object> request;
	    
	/**
	 * ���е�Service����
	 */
	@Resource
	protected FileUpload fileUpload ;


	@Resource
	protected AdminService adminService;
	@Resource
	protected CatalogService catalogService;
	@Resource
	protected CommentService commentService;
	@Resource
	protected NewsService newsService;
	@Resource
	protected SteelproductService steelproductService;
	@Resource
	protected UserService userService;
	//@Resource
	//protected  FileUpload  fileUpload;
	//ע�ⲻ�� set ����
	public void setFileUpload(FileUpload fileUpload) {
		this.fileUpload = fileUpload;
	}

	public void setAdminService(AdminService adminService) {
		this.adminService = adminService;
	}
	
	public void setCatalogService(CatalogService catalogService) {
		this.catalogService = catalogService;
	}

	public void setCommentService(CommentService commentService) {
		this.commentService = commentService;
	}

	public void setNewsService(NewsService newsService) {
		this.newsService = newsService;
	}

	public void setSteelproductService(SteelproductService steelproductService) {
		this.steelproductService = steelproductService;
	}

	public void setUserService(UserService userService) {
		this.userService = userService;
	}

	/**
	 * ͨ�����䴴������
	 */
	@SuppressWarnings("unchecked")
	@Override
	public T getModel() {
		// TODO Auto-generated method stub
		 ParameterizedType type =(ParameterizedType)this.getClass().getGenericSuperclass();
		@SuppressWarnings("rawtypes")
		Class clazz=(Class)type.getActualTypeArguments()[0];
		 try {
			model=(T) clazz.newInstance();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			throw new RuntimeException(e);
		}
		return model;
	}
	
	public FileImage getFileImage() {
		return fileImage;
	}

	public void setFileImage(FileImage fileImage) {
		this.fileImage = fileImage;
	}

	@Override
	public void setApplication(Map<String, Object> application) {
		// TODO Auto-generated method stub
		this.appliction=application;
		
	}

	@Override
	public void setSession(Map<String, Object> session) {
		// TODO Auto-generated method stub
		this.session=session;
		
	}

	@Override
	public void setRequest(Map<String, Object> request) {
		// TODO Auto-generated method stub
		this.request=request;
	}

	public List getData() {
		return data;
	}

	public void setData(List data) {
		this.data = data;
	}

	public int getTotalRow() {
		return totalRow;
	}

	public void setTotalRow(int totalRow) {
		this.totalRow = totalRow;
	}

	public int getTotalPage() {
		return totalPage;
	}

	public void setTotalPage(int totalPage) {
		this.totalPage = totalPage;
	}

	public int getCurrentPage() {
		return currentPage;
	}

	public void setCurrentPage(int currentPage) {
		this.currentPage = currentPage;
	}

	public int getPageSize() {
		return pageSize;
	}

	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}

	public int getParam() {
		return param;
	}

	public void setParam(int param) {
		this.param = param;
	}
	
	
	public Page getCurrentPageInfo(){
		return new Page(totalRow, totalPage, currentPage, pageSize, param);
	}
	

}
