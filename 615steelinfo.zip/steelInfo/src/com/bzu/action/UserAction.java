package com.bzu.action;

import org.springframework.stereotype.Controller;

import com.bzu.entity.User;
@Controller
public class UserAction extends BaseAction<User> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	/** 
	* �����û��Ƿ���� 
	* 
	* @return 
	* @throws IOException 
	*/ 
	/*public String findByName() throws IOException { 
	List<User> listPerson = userService.findByName(); 
	String findByNameTip; 
	if (listPerson.size() > 0) { 
	findByNameTip = "exist"; // �����û� 
	} else { 
	findByNameTip = "noexist"; // �������û� 
	} 
	ServletActionContext.getResponse().getWriter().print(findByNameTip); 
	return null; 
	} */
	
	public String userupdate(){
		 User user=(User)session.get("user");
		 user.setUserpw(model.getUserpw());
		 user.setRealname(model.getRealname());
		 user.setEmail(model.getEmail());
		 user.setPhone(model.getPhone());
		 user.setQq(model.getQq());
		 userService.update(user);
		return "success";
	}
	public String list() {
		session.put("userlist", userService.pageList(getCurrentPageInfo()));
		@SuppressWarnings("unused")
		
		Object object= userService.pageList(getCurrentPageInfo()).getData();
		
		return "success";
			
	}
	
/**
 * �û���¼
 * @return
 */
	public String login(){
		 User user=userService.login(model.getUsername(), model.getUserpw());
		if(user!=null){
			session.put("user", user);
			System.out.println("success___login______________");
		   return "success";
		}
	    else{
		return "fail";
	        }
	    }
	/**
	 * �û�ע��
	 * @return
	 */
	public String logout() {
		session.remove("user");
		Object o=session.get("user");
		
		System.out.println("logout success------------null--"+o);	
		return "success";
	}
	/**
	 * �û���¼ע��
	 * @return
	 */
	public String add() {
		try {
			System.out.println("modelΪ"+model.toString());
			userService.add(model);
			return "success";
		} catch (Exception e) {
			// TODO: handle exception
			throw new RuntimeException(e);
		}
		
	}
	/**
	 * �û��޸�����
	 * @return
	 */
	public String updatepw()
	 {
		System.out.println(model.toString());
	    
		  int id=model.getId();
		  User user =userService.get(id);
		  user.setUserpw(model.getUserpw());
		  userService.update(user);
		 return "success";
	 }
		 @SuppressWarnings("unused")
		 
	public String update()
	 {
		System.out.println(model.toString());
	    
		  int id=model.getId();
		// ���޸�  
		 userService.update(model);
		 return "success";
	 }
	 
public String delete() {
	
	try {
		
		userService.delete((int)request.get("id"));
	    return "success";
		
	} catch (Exception e) {
		// TODO: handle exception
		
		throw new RuntimeException(e);
	}
	}


}
