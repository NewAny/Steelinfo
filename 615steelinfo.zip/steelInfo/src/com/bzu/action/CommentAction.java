package com.bzu.action;

import com.bzu.entity.Comment;
import com.bzu.entity.User;
import com.bzu.tools.DateUtils;

public class CommentAction extends BaseAction<Comment>{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public String list() {
		session.put("commentlist", commentService.pageList(getCurrentPageInfo()));
		@SuppressWarnings("unused")
		
		Object object= commentService.pageList(getCurrentPageInfo()).getData();
		
		return "success";
			
	}
	public String querylistByuserid() {
	//	session.put("commentlistforuser", commentService.pageList(getCurrentPageInfo()));
		int id=((User)session.get("user")).getId();
		session.put("commentlistforuser", commentService.queryListByuserid(id));
		return "success";
	}
	public String addcomment() {
		try {		
		model.setTime(DateUtils.currentDatetime());
		  
		int receiveUserId=steelproductService.get(model.getProductid()).getUserId();//��ȡ������id
		model.setReceiveid(receiveUserId); 
		model.setUserid(((User)session.get("user")).getId());
		System.out.println("modelΪ"+model.toString());
			commentService.add(model);
			return "success";
		} catch (Exception e) {
			// TODO: handle exception
			throw new RuntimeException(e);
		}
	}
		 @SuppressWarnings("unused")
	public String update()
	 {
		System.out.println(model.toString());
	    
		  int id=model.getId();
		  
		 commentService.update(model);
		 return "success";
	 }
	 
public String delete() {
	
	try {
		
		commentService.delete((int)request.get("id"));
	    return "success";
		
	} catch (Exception e) {
		// TODO: handle exception
		
		throw new RuntimeException(e);
	}
		 
		 
		
		
	}

}
