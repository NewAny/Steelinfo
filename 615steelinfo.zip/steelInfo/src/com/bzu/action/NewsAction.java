package com.bzu.action;

import java.util.Date;

import org.apache.struts2.ServletActionContext;

import com.bzu.entity.News;
import com.bzu.entity.User;
import com.bzu.tools.DateUtils;

public class NewsAction extends BaseAction<News>{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public String newsList() {
		session.put("newslist", newsService.pageList(getCurrentPageInfo()));
		@SuppressWarnings("unused")
		
		Object object= newsService.pageList(getCurrentPageInfo()).getData();
		
		return "success";
	
	}
	
       /**
        * ��������
        * @return
        */
	public String add() {
		try {
			System.out.println("====model===:"+model.toString());
			if(fileImage.getFile()!=null){//�ϴ�ͼƬ��Ϊ��
				System.out.println("==fileIamge+="+fileImage.toString());
				System.out.println("====model===:"+model.toString());
				//String realpath = ServletActionContext.getServletContext()
				String realpath = ServletActionContext.getServletContext().getRealPath("/upload");
		        System.out.println("-------realpath-----"+realpath);
				 fileUpload.setFilePath(realpath);
				System.out.println("====realpath==: "+realpath);
			    String pic=  fileUpload.uploadFile(fileImage);
			     model.setImage(pic);//�����·��
			}
			  
			    model.setTime(DateUtils.currentDatetime());
			     
			    System.out.println("news  -----willsave"+model.toString());
			   
			     newsService.add(model);
			     System.out.println("steel  -----willsave---successful-- "+model.toString());
				return "success";
				
		} catch (Exception e) {
		
			throw new RuntimeException(e);
		}
		
		
	}
		 @SuppressWarnings("unused")
	public String update()
	 {
		System.out.println(model.toString());
	    
		  int id=model.getId();
		  
		 newsService.update(model);
		 return "success";
	 }
	 
public String delete() {
	
	try {
		
		newsService.delete((int)request.get("id"));
	    return "success";
		
	} catch (Exception e) {
		// TODO: handle exception
		
		throw new RuntimeException(e);
	}
		 
		 
		
		
	}

}
