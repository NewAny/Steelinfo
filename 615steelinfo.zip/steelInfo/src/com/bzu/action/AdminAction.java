package com.bzu.action;

import com.bzu.entity.Admin;
import com.bzu.entity.Page;


public class AdminAction extends BaseAction<Admin> {
	
	 /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
/*	public int id;
	
	public void setId(int id) {
		this.id = id;
	}*/

	public String login(){
		if(adminService.login(model.getAdminname(), model.getAdminpw())!=null){
			//session.put("admin", model);
			session.put("admin", model);
			System.out.println("success___login______________");
		   return "success";
		}
	    else{
		return "fail";
	        }
	    }
	/**
	 * �û�ע��
	 * @return
	 */
	public String logout() {
		session.remove("admin");
		Object o=session.get("user");
		
		System.out.println("logout success------------null--"+o);	
		return "success";
	}
	public String add() {
		try {
			System.out.println("adddddddadd-----------addad"+model.toString());
			adminService.add(model);
			return "success";
		} catch (Exception e) {
			// TODO: handle exception
			throw new RuntimeException(e);
		}
		
		
	}
	 public String list(){
		 session.put("adminlist", adminService.pageList(getCurrentPageInfo()));
		 System.out.println(adminService.pageList(getCurrentPageInfo()).getData().toString());
		 return "success";
		 
		 
	 }
	 @SuppressWarnings("unused")
	public String update()
	 {
		System.out.println(model.toString());
	     String name=  model.getAdminname();
		  int id=model.getId();
		  String pw=model.getAdminpw();
		 adminService.update(model);
		 return "success";
	 }
	 
public String delete() {
	
	try {
		
		adminService.delete((int)request.get("id"));
	    return "success";
		
	} catch (Exception e) {
		// TODO: handle exception
		throw new RuntimeException(e);
	}
		 
		 
		
		
	}
	/* test public void name() {
		 //ʵ���ļ��ϴ����ܣ�Ȼ������Ψһ��uuid�ļ������ظ�pic�������ݿ�
		String pic=fileUpload.uploadFile(fileImage);
		//���save
	}*/
	

}
