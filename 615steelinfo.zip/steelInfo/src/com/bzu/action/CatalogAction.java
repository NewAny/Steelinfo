package com.bzu.action;

import java.util.List;
import java.util.Map;

import com.bzu.entity.Catalog;

public class CatalogAction extends BaseAction<Catalog> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public String list() {
		 @SuppressWarnings("unused")
		List<Map<String, Object>> list = catalogService.queryAllList();
		session.put("cataloglist", catalogService.queryAllList());

		return "success";

	}

	public String add() {
		try {
			System.out.println("modelΪ" + model.toString());
		//	Catalog catalog=model;
			catalogService.add(model);
			return "success";
		} catch (Exception e) {
			// TODO: handle exception
			throw new RuntimeException(e);
		}

	}

	
	public String update() {
		System.out.println(model.toString());

		//int id = model.getId();

		catalogService.update(model);
		return "success";
	}

	public String delete() {

		try {

			catalogService.delete((int) request.get("id"));
			return "success";

		} catch (Exception e) {
			// TODO: handle exception

			throw new RuntimeException(e);
		}

	}
}