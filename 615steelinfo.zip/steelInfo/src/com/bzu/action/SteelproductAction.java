package com.bzu.action;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.struts2.ServletActionContext;

import com.bzu.entity.Page;
import com.bzu.entity.Steelproduct;
import com.bzu.entity.User;


public class SteelproductAction extends BaseAction<Steelproduct> {

	private static final long serialVersionUID = 1L;
	
	
	
	/**
	 * ������Ϣ
	 * @return
	 */
	public String   addSteelproductInfo(){
		 /*if(file!=null)
			 //����ļ��ľ���·��d
		*/
		System.out.println("====model===:"+model.toString());
		
		if(fileImage!=null){//�ϴ�ͼƬ��Ϊ��
			System.out.println("==fileIamge+="+fileImage.toString());
			System.out.println("====model===:"+model.toString());
			//String realpath = ServletActionContext.getServletContext()
			String realpath = ServletActionContext.getServletContext().getRealPath("/upload");
	        System.out.println("-------realpath-----"+realpath);
			 fileUpload.setFilePath(realpath);
			System.out.println("====realpath==: "+realpath);
		    String pic=  fileUpload.uploadFile(fileImage);
		     model.setImage(pic);//�����·��
		}
		     model.setUserId(((User)session.get("user")).getId());//������
		     model.setReleasetime(new Date());
		     
		   System.out.println("steel  -----willsave"+model.toString());
		   System.out.println("====model===:"+model.toString());
		     steelproductService.add(model);
		     System.out.println("steel  -----willsave---successful-- "+model.toString());
			return "success";
	}
	/**
	 * ȡ�ø��������Ϣ�б�
	 * @return
	 */
	public String list() {
		session.put("steelproductlist", steelproductService.pageList(getCurrentPageInfo()));		
		return "success";
			
	}
	/**
	 * �����б�
	 * @return
	 */
	public String gongqiulist(){
		Page currentPageInfo = getCurrentPageInfo();
		currentPageInfo.setParam(0);
		Page pageList = steelproductService.leftJoinPageList(currentPageInfo );//pageList(getCurrentPageInfo());
		System.out.println(pageList.toString());
		session.put("pageList", pageList);
		System.out.println(pageList);
		return "success";
	}
	/**
	 * ��Ӧ�б�
	 * @return
	 */
	public String gongyinglist(){
		Page currentPageInfo = getCurrentPageInfo();
		currentPageInfo.setParam(1);
		Page pageList = steelproductService.leftJoinPageList(currentPageInfo);
		//session.put("pageList", pageList);
		session.put("pageList", pageList);

		System.out.println(pageList);
		return "success";
	}
	/**
	 * ���б�
	 * @return
	 */
	public String qiugoulist(){
		Page currentPageInfo = getCurrentPageInfo();
		currentPageInfo.setParam(2);//param:2 ��
		Page pageList = steelproductService.leftJoinPageList(currentPageInfo);
		session.put("pageList", pageList);
		System.out.println(pageList);
		return "success";
	}
	/**
	 * �����û�
	 * @return
	 */
	public String add() {
		try {
			System.out.println("modelΪ"+model.toString());
			steelproductService.add(model);
			return "success";
		} catch (Exception e) {
			// TODO: handle exception
			throw new RuntimeException(e);
		}
		
		
	}
	/**
	 * ��Ϣ�޸�
	 * @return
	 */
		 @SuppressWarnings("unused")
	public String update()
	 {
		System.out.println(model.toString());
	    
		 Steelproduct steelproduct = steelproductService.get(model.getId());
         steelproduct.setCatalogId(model.getCatalogId());
         steelproduct.setTitle(model.getTitle());
         steelproduct.setGuige(model.getGuige());
         steelproduct.setShuliang(model.getShuliang());
         steelproduct.setDescription(model.getDescription());
         steelproduct.setReleasetime(new Date()); 
		 steelproductService.update(steelproduct);
		 return "success";
	 }
	 
public String delete() {
	
	try {
		
		steelproductService.delete((int)request.get("id"));
	    return "success";
		
	} catch (Exception e) {
		// TODO: handle exception
		
		throw new RuntimeException(e);
	 }		
	}
/**
 * �û��ѷ�������Ϣ
 * @return
 */
public String  yifabu(){
	int id=((User)session.get("user")).getId();
	 @SuppressWarnings("unused")
	List<Map<String, Object>> lsit = steelproductService.queryAllListByUserId( id);
   session.put("yifabu", steelproductService.queryAllListByUserId( id));
	return "success";
}
}
